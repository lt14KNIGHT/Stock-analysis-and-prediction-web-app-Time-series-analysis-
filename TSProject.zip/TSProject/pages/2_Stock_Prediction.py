import streamlit as st
import pandas as pd


from pages.utils.model_train import (
    get_data, get_rolling_mean, get_differencing_order, 
    scaling, evaluate_model, get_forecast, 
    inverse_scaling, fit_model
)


from pages.utils.plotly_figure import (
    plotly_table, Moving_average_forecast
)


st.set_page_config(
    page_title='Stock prediction',
    page_icon='chart_with_upwards_trend',
    layout='wide'
    )
st.title('Stock prediction')

col1,col2,col3=st.columns(3)

with col1:
    ticker=st.text_input('Stock Ticker','AAPL')
rmse=0

st.subheader('Predicting next 30 days close price for: '+ticker)

close_price=get_data(ticker)
rolling_price=get_rolling_mean(close_price)
differencing_order=get_differencing_order(rolling_price)
scaled_data,scaler=scaling(rolling_price)

rmse=evaluate_model(scaled_data, differencing_order, scaler)

st.write('**Model RMSE Score:**', rmse) # Fixed the typo


predictions_array = get_forecast(scaled_data, differencing_order)

forecast_index = pd.date_range(
    start=rolling_price.index[-1] + pd.Timedelta(days=1),
    periods=30,
    freq='D'
)


forecast_df = pd.DataFrame(predictions_array, index=forecast_index, columns=['Close'])


forecast_df['Close'] = inverse_scaling(scaler, forecast_df['Close'])


forecast_df['Close'] = pd.to_numeric(forecast_df['Close'], errors='coerce')
forecast_df = forecast_df.dropna()


if isinstance(rolling_price, pd.Series):
    rolling_price = rolling_price.to_frame(name="Close")
elif "Close" not in rolling_price.columns:
    rolling_price.columns = ["Close"]


if isinstance(rolling_price.columns, pd.MultiIndex):
    rolling_price.columns = rolling_price.columns.get_level_values(-1)

if isinstance(forecast_df.columns, pd.MultiIndex):
    forecast_df.columns = forecast_df.columns.get_level_values(-1)


rolling_price = rolling_price.rename(columns={rolling_price.columns[0]: "Close"})
forecast_df = forecast_df.rename(columns={forecast_df.columns[0]: "Close"})


combined_df = pd.concat([rolling_price, forecast_df])
combined_df = combined_df.sort_index()



st.write("Combined DF preview:", combined_df.tail())


if not combined_df.empty:
    st.plotly_chart(Moving_average_forecast(combined_df), use_container_width=True)
else:
    st.warning("Combined DataFrame is empty — check forecast generation.")
