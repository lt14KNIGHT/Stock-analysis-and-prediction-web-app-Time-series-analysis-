import streamlit as st
st.set_page_config(
    page_title='Trading guide',
    page_icon=':writing_hand:',
    layout='wide'
    )

st.title('Trading guide :writing_hand:')
st.header('by LT14KNIGHT')
st.image('w60giljc.png')

st.markdown('## Features:')

st.markdown('#### :one: Stock info')
st.write('Explore information pertaining to each stock')

st.markdown('#### :two: Stock prediction')
st.write('You can explore predicted closing prices for the next 30 days based on historical stock data and advanced forecasting models')

st.markdown('#### :three: Return calculation')
st.write('Calculated using CAPM model')

st.markdown('#### :four: Volatility and risk')
st.write('Calculates the value of beta and expected return for individual stocks')

